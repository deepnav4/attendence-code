Simple HTML project
Structure:
- index.html
- css/style.css
- js/script.js
- img/sample.svg

How to use:
Open index.html in your browser.
Open css/style.css to see the styles.
Open js/script.js to see the JavaScript code.